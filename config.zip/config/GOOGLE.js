module.exports = {
  key: 'AIzaSyDGZMTb_uccDom9FtaJZ1zfxgbajgzOl3A',
};
