module.exports = {
  secret: '4IJmlOSL80BueS927GgteKLyIVv2Jw7hQzlmOte6Hq6z4JOtfIue4jD8tO7XTc6f',
};
